<?php
/**
 * Laravel Cache Cleaner for Shared Hosting
 * WARNING: Delete this file after use!
 */

// Set the base path
$basePath = __DIR__ . '/..';

echo "<html><head><title>Laravel Cache Cleaner</title>";
echo "<style>
body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
.container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h1 { color: #333; margin-bottom: 20px; }
.success { color: #059669; background: #d1fae5; padding: 10px; border-radius: 5px; margin: 10px 0; }
.error { color: #dc2626; background: #fee2e2; padding: 10px; border-radius: 5px; margin: 10px 0; }
.warning { color: #d97706; background: #fef3c7; padding: 15px; border-radius: 5px; margin: 20px 0; font-weight: bold; }
</style></head><body><div class='container'>";

echo "<h1>🧹 Laravel Cache Cleaner</h1>";

$results = [];

// Clear view cache
$viewPath = $basePath . '/storage/framework/views';
if (is_dir($viewPath)) {
    $files = glob($viewPath . '/*');
    $count = 0;
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
            $count++;
        }
    }
    $results[] = ['success', "View cache cleared ($count files)"];
} else {
    $results[] = ['error', "View cache directory not found"];
}

// Clear compiled cache
$cachePath = $basePath . '/storage/framework/cache/data';
if (is_dir($cachePath)) {
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($cachePath, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    $count = 0;
    foreach ($iterator as $file) {
        if ($file->isFile() && $file->getFilename() !== '.gitignore') {
            unlink($file->getPathname());
            $count++;
        }
    }
    $results[] = ['success', "Application cache cleared ($count files)"];
}

// Clear config cache
$configCache = $basePath . '/bootstrap/cache/config.php';
if (file_exists($configCache)) {
    unlink($configCache);
    $results[] = ['success', "Config cache cleared"];
}

// Clear route cache
$routeCache = $basePath . '/bootstrap/cache/routes-v7.php';
if (file_exists($routeCache)) {
    unlink($routeCache);
    $results[] = ['success', "Route cache cleared"];
}

// Clear OPcache if available
if (function_exists('opcache_reset')) {
    opcache_reset();
    $results[] = ['success', "OPcache cleared"];
}

// Display results
foreach ($results as $result) {
    echo "<div class='{$result[0]}'>{$result[1]}</div>";
}

echo "<div class='warning'>⚠️ กรุณาลบไฟล์นี้ (clear-cache.php) หลังใช้งานเสร็จ!</div>";
echo "<p><a href='/'>← กลับหน้าหลัก</a></p>";
echo "</div></body></html>";
